<?php
/**
 * Plugin Name: QwicPay Checkout
 * Plugin URI: https://www.qwicpay.com/
 * Description: Adds a QwicPay instant checkout button to WooCommerce, supports classic and block themes.
 * Version: 1.3.0
 * Author: QwicPay Pty Ltd
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: qwicpay-checkout
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'QWICPAY_CHECKOUT_MIN_PHP', '7.4' );

// Check requirements before initializing
add_action( 'plugins_loaded', function () {
    if ( version_compare( PHP_VERSION, QWICPAY_CHECKOUT_MIN_PHP, '<' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'QwicPay Checkout requires PHP version 7.4 or higher.', 'qwicpay-checkout' ) . '</p></div>';
        } );
        return;
    }
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'QwicPay Checkout requires WooCommerce to be installed and active.', 'qwicpay-checkout' ) . '</p></div>';
        } );
        return;
    }

    new QwicPayCheckout_Integration();
}, 11 );

class QwicPayCheckout_Integration {

    public function __construct() {
        // Admin & settings
        add_filter( 'woocommerce_settings_tabs_array', [ $this, 'add_settings_tab' ], 50 );
        add_action( 'woocommerce_settings_tabs_qwicpay', [ $this, 'settings_tab' ] );
        add_action( 'woocommerce_update_options_qwicpay', [ $this, 'update_settings' ] );
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'admin_init', [ $this, 'qwicpay_checkout_check_endpoints' ] );

        // Button integration on frontend
        add_action( 'init', [ $this, 'register_button_integration' ] );
    }

    /**
     * Determine theme type and register appropriate hooks or blocks
     */
    public function register_button_integration() {
        if ( current_theme_supports( 'block-templates' ) && function_exists( 'register_block_hook' ) ) {
            $this->register_block_integration();
        } else {
            $this->register_classic_hooks();
        }
    }

    /**
     * Classic themes: hook into WooCommerce PHP actions
     */
    private function register_classic_hooks() {
        $hook = get_option( 'qwicpay_hook_location', 'woocommerce_cart_totals_after_order_total' );
        add_action( $hook, [ $this, 'output_qwicpay_button_full' ], 5 );
        add_action( 'woocommerce_widget_shopping_cart_total', [ $this, 'output_qwicpay_button_half' ], 5 );
    }

    /**
     * Block themes: register dynamic block and inject via block hooks
     */
    private function register_block_integration() {
        register_block_type( 'qwicpay/checkout-button', [
            'render_callback' => function() {
                return self::render_button_html( '100%' );
            },
        ] );

        // Inject after cart totals block
        register_block_hook( 'woocommerce/cart-totals', 'after', 'qwicpay/checkout-button' );
        // Inject before checkout submit block
        register_block_hook( 'woocommerce/checkout-submit', 'before', 'qwicpay/checkout-button' );
    }

    /** Classic output wrappers **/
    public function output_qwicpay_button_full() {
        echo self::render_button_html( '100%' );
    }
    public function output_qwicpay_button_half() {
        echo self::render_button_html( '50%' );
    }

    /**
     * Shared button HTML generator
     */
    public static function render_button_html( $width ) {
        $merchant_id = sanitize_text_field( get_option( 'qwicpay_merchant_id', '' ) );
        $stage       = get_option( 'qwicpay_stage', 'test' );
        $currency    = get_option( 'qwicpay_currency', 'ZAR' );
        $button_url  = esc_url( get_option( 'qwicpay_button_style' ) );

        if ( empty( $merchant_id ) ) {
            return '';
        }

        $response = wp_remote_get( "https://ice.qwicpay.com/isup/{$merchant_id}", [ 'timeout' => 5 ] );
        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return '';
        }

        // Build products payload
        $coupons   = WC()->cart->get_applied_coupons();
        $promocode = ! empty( $coupons ) ? array_shift( $coupons ) : '';
        $products  = [];
        foreach ( WC()->cart->get_cart() as $item ) {
            $qty = intval( $item['quantity'] );
            for ( $i = 0; $i < $qty; $i++ ) {
                $products[] = [
                    'product_id'   => $item['product_id'],
                    'variation_id' => ! empty( $item['variation_id'] ) ? $item['variation_id'] : 0,
                ];
            }
        }
        $products_json = urlencode( wp_json_encode( $products ) );

        // Build URL
        $checkout_url = add_query_arg(
            [
                'merchantid' => $merchant_id,
                'stage'      => $stage,
                'promocode'  => $promocode,
                'currency'   => $currency,
                'products'   => $products_json,
            ],
            'https://ice.qwicpay.com/app/woo/checkout/'
        );

        return sprintf(
            '<a href="%s" target="_blank" class="qwicpay-checkout-button" style="width:%s;"><img src="%s" alt="QwicPay Checkout Button" style="width:100%%;height:auto;"></a>',
            esc_url( $checkout_url ),
            esc_attr( $width ),
            esc_url( $button_url )
        );
    }

    /**
     * Admin: add settings tab
     */
    public function add_settings_tab( $tabs ) {
        $tabs['qwicpay'] = __( 'QwicPay Settings', 'qwicpay-checkout' );
        return $tabs;
    }

    public function settings_tab() {
        woocommerce_admin_fields( $this->get_settings() );
        $this->display_link_status();
        $this->display_activate_button();
    }

    public function update_settings() {
        woocommerce_update_options( $this->get_settings() );
    }

    private function get_settings() {
        return [
            [ 'name' => __( 'QwicPay Settings', 'qwicpay-checkout' ), 'type' => 'title', 'id' => 'qwicpay_section_title' ],
            [ 'name' => __( 'Hook Location', 'qwicpay-checkout' ), 'id' => 'qwicpay_hook_location', 'type' => 'select', 'options' => [ 'woocommerce_cart_totals_after_order_total' => 'Cart Totals After Order Total', 'woocommerce_proceed_to_checkout' => 'Proceed to Checkout Button', 'woocommerce_review_order_before_submit' => 'Before Place Order Button' ], 'default' => 'woocommerce_cart_totals_after_order_total' ],
            [ 'name' => __( 'Merchant ID', 'qwicpay-checkout' ), 'id' => 'qwicpay_merchant_id', 'type' => 'text', 'desc' => __( 'Your QwicPay Merchant ID.', 'qwicpay-checkout' ), 'default' => '' ],
            [ 'name' => __( 'Stage', 'qwicpay-checkout' ), 'id' => 'qwicpay_stage', 'type' => 'select', 'options' => [ 'test' => 'Test', 'PROD' => 'Production' ], 'default' => 'test' ],
            [ 'name' => __( 'Currency', 'qwicpay-checkout' ), 'id' => 'qwicpay_currency', 'type' => 'select', 'options' => [ 'ZAR' => 'ZAR' ], 'default' => 'ZAR' ],
            [ 'name' => __( 'Button Style', 'qwicpay-checkout' ), 'id' => 'qwicpay_button_style', 'type' => 'select', 'options' => [ plugins_url( 'assets/buttons/QwicPay+Button+BlueBGWhiteText.svg', __FILE__ ) => __( 'Blue Round', 'qwicpay-checkout' ), plugins_url( 'assets/buttons/QwicPay+Button+BlueBGWhiteText+(Squared).svg', __FILE__ ) => __( 'Blue Square', 'qwicpay-checkout' ), plugins_url( 'assets/buttons/QwicPay+Button+WhiteBGBlueText.svg', __FILE__ ) => __( 'White Round', 'qwicpay-checkout' ), plugins_url( 'assets/buttons/QwicPay+Button+WhiteBGBlueText+(Squared).svg', __FILE__ ) => __( 'White Square', 'qwicpay-checkout' ) ], 'default' => plugins_url( 'assets/buttons/QwicPay+Button+BlueBGWhiteText.svg', __FILE__ ) ],
            [ 'type' => 'sectionend', 'id' => 'qwicpay_section_end' ],
        ];
    }

    private function display_link_status() {
        $merchant_id = sanitize_text_field( get_option( 'qwicpay_merchant_id', '' ) );
        $status = 'Not Activated';
        if ( $merchant_id ) {
            $response = wp_remote_get( "https://ice.qwicpay.com/app/woo/status/{$merchant_id}", [ 'timeout' => 5 ] );
            if ( ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 ) {
                $status = '<span style="color: green; font-weight: bold;">Activated</span>';
            } else {
                $status = '<span style="color: red; font-weight: bold;">Not Activated</span>';
            }
        }
        echo '<h2>QwicPay Link Status</h2><p>Status: ' . $status . '</p>';
    }

    private function display_activate_button() {
        $merchant_id = sanitize_text_field( get_option( 'qwicpay_merchant_id', '' ) );
        echo '<a href="' . esc_url( "https://ice.qwicpay.com/app/woo/link/{$merchant_id}" ) . '" class="button button-primary" target="_blank">Activate / Re-Activate</a>';
    }

    public function add_admin_menu() {
        add_menu_page( 'QwicPay', 'QwicPay', 'manage_options', 'qwicpay-main', '__return_false', plugin_dir_url( __FILE__ ) . 'assets/qwicpay-icon.png', 56 );
        add_submenu_page( 'qwicpay-main', 'Merchant Access Portal', 'Merchant Access Portal', 'manage_options', 'qwicpay-portal', [ $this, 'render_portal_page' ] );
        add_submenu_page( 'qwicpay-main', 'Settings', 'Settings', 'manage_options', 'qwicpay-settings', [ $this, 'render_settings_redirect' ] );
        remove_submenu_page( 'qwicpay-main', 'qwicpay-main' );
    }

    public function render_settings_redirect() {
        wp_safe_redirect( admin_url( 'admin.php?page=wc-settings&tab=qwicpay' ) );
        exit;
    }

    public function render_portal_page() {
        echo '<div class="wrap"><h1>Merchant Access Portal</h1><iframe src="https://map.qwicpay.com" width="100%" height="800px" style="border:none;"></iframe></div>';
    }

    public function qwicpay_checkout_check_endpoints() {
        $pay      = get_option( 'woocommerce_checkout_pay_endpoint' );
        $received = get_option( 'woocommerce_checkout_order_received_endpoint' );
        if ( $pay !== 'order-pay' || $received !== 'order-received' ) {
            add_action( 'admin_notices', function() {
                echo '<div class="notice notice-warning"><p>' . esc_html__( 'QwicPay Checkout requires WooCommerce checkout endpoints to be correctly configured.', 'qwicpay-checkout' ) . '</p></div>';
            } );
        }
    }
}
